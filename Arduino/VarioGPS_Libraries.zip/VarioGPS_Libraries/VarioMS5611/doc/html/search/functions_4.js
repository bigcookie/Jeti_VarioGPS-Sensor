var searchData=
[
  ['setoversampling_57',['setOversampling',['../classVarioMS5611.html#ab8570bf3e54dd8b06757b1001ea8671a',1,'VarioMS5611']]],
  ['setpressuresmoothingfactor_58',['setPressureSmoothingFactor',['../classVarioMS5611.html#a16a66da734b815069d3d41650e6fe36f',1,'VarioMS5611']]],
  ['setsecondordercompenstation_59',['setSecondOrderCompenstation',['../classVarioMS5611.html#a4e6aeb202d89a6756d886a23d5171d82',1,'VarioMS5611']]],
  ['setverticalspeedsmoothingfactor_60',['setVerticalSpeedSmoothingFactor',['../classVarioMS5611.html#afad885c081fca9cf278f8cf2df2b4b8b',1,'VarioMS5611']]]
];
