var searchData=
[
  ['getoversampling_3',['getOversampling',['../classVarioMS5611.html#ac166288cdfcbbc362fba107a064acfe1',1,'VarioMS5611']]],
  ['getpressure_4',['getPressure',['../classVarioMS5611.html#ab0e4e47bfccb9356e49ebde447c9d79b',1,'VarioMS5611']]],
  ['getpressuresmoothingfactor_5',['getPressureSmoothingFactor',['../classVarioMS5611.html#a114e1a5df8a4752c0b9eb55919889c2b',1,'VarioMS5611']]],
  ['getrawpressure_6',['getRawPressure',['../classVarioMS5611.html#aad62d9a3dd3910158b17f7d1c576eeaa',1,'VarioMS5611']]],
  ['getrawtemperature_7',['getRawTemperature',['../classVarioMS5611.html#a56050003bc367e628537040c1e004044',1,'VarioMS5611']]],
  ['getreadspersecond_8',['getReadsPerSecond',['../classVarioMS5611.html#aee7403ebd60e50423262cbcff3294bfe',1,'VarioMS5611']]],
  ['getreferenceheight_9',['getReferenceHeight',['../classVarioMS5611.html#a6ba10a43a3a79879e94d23f3a0479325',1,'VarioMS5611']]],
  ['getruncount_10',['getRunCount',['../classVarioMS5611.html#a4138de3fe3ddf5c8e020d7de3a6efda9',1,'VarioMS5611']]],
  ['getsecondordercompenstation_11',['getSecondOrderCompenstation',['../classVarioMS5611.html#ab5d21024d2805f922d7f40f634d5639d',1,'VarioMS5611']]],
  ['getsmoothedpressure_12',['getSmoothedPressure',['../classVarioMS5611.html#a85ad8f7f4e0b6d02a91dc2a19e67e6e1',1,'VarioMS5611']]],
  ['gettemperature_13',['getTemperature',['../classVarioMS5611.html#a5a67cf918f2e3d127f8933346a35e891',1,'VarioMS5611']]],
  ['getverticalspeed_14',['getVerticalSpeed',['../classVarioMS5611.html#a25f821f9c70b70a80bf8fa90649e3875',1,'VarioMS5611']]],
  ['getverticalspeedsmoothingfactor_15',['getVerticalSpeedSmoothingFactor',['../classVarioMS5611.html#a5f7815cb02d73ae1afa91e5b332ab987',1,'VarioMS5611']]]
];
