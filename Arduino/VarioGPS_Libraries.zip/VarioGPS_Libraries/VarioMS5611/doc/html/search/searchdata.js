var indexSectionsWithContent =
{
  0: "bcgmrsv",
  1: "v",
  2: "v",
  3: "bcgrs",
  4: "m",
  5: "m",
  6: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator",
  6: "Pages"
};

