var searchData=
[
  ['calcaltitude_37',['calcAltitude',['../classVarioMS5611.html#a95cebbd56d716ed28eeb8dfd3eea0bc8',1,'VarioMS5611']]],
  ['calcrelaltitude_38',['calcRelAltitude',['../classVarioMS5611.html#a51e6643ba557be1d7ca8a9722a271788',1,'VarioMS5611']]]
];
